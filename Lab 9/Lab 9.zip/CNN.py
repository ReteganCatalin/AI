# -*- coding: utf-8 -*-
"""
Created on Fri May 15 14:51:11 2020

@author: Catalin
"""


import numpy as np 
import keras  
from keras.datasets import mnist 
from keras.models import Sequential
from keras.layers import Dense, Input
from keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten 
from keras import backend as k 

class CNN:
    
    def __init__(self):
        return
        
    
    def ReInitCNN(self):
        self.NumOfClasses=10
        self.epochNo=12
        self.batchSize=128
        (self.x_train, self.y_train), (self.x_test, self.y_test) = mnist.load_data()     
        self.img_rows, self.img_cols=28, 28
        self.Reshaping()
        self.Reshaping()
        self.Categories()
        self.CNNModel()
        
    def Reshaping(self):
        if k.image_data_format() == 'channels_first': 
           self.x_train = self.x_train.reshape(self.x_train.shape[0], 1, self.img_rows, self.img_cols) 
           self.x_test = self.x_test.reshape(self.x_test.shape[0], 1, self.img_rows, self.img_cols) 
           self.inpx = (1, self.img_rows, self.img_cols) 
          
        else: 
           self.x_train = self.x_train.reshape(self.x_train.shape[0], self.img_rows, self.img_cols, 1) 
           self.x_test = self.x_test.reshape(self.x_test.shape[0], self.img_rows, self.img_cols, 1) 
           self.inpx = (self.img_rows, self.img_cols, 1) 
          
        self.x_train = self.x_train.astype('float32') 
        self.x_test = self.x_test.astype('float32') 
        self.x_train /= 255
        self.x_test /= 255
        
    def Categories(self):   
        self.y_train = keras.utils.to_categorical(self.y_train) 
        self.y_test = keras.utils.to_categorical(self.y_test) 
        
    def CNNModel(self):
        self.model = Sequential()
        self.model.add(Conv2D(32, kernel_size=(3, 3),
                         activation='relu',
                         input_shape=self.inpx))
        self.model.add(Conv2D(64, (3, 3), activation='relu'))
        self.model.add(MaxPooling2D(pool_size=(2, 2)))
        self.model.add(Dropout(0.25))
        self.model.add(Flatten())
        self.model.add(Dense(128, activation='relu'))
        self.model.add(Dropout(0.5))
        self.model.add(Dense(self.NumOfClasses, activation='softmax'))
        
    def ModelStart(self):
     
        self.model.compile(optimizer=keras.optimizers.Adadelta(), 
                      loss=keras.losses.categorical_crossentropy, 
                      metrics=['accuracy']) 
        self. model.fit(self.x_train, self.y_train,
          batch_size=self.batchSize,
          epochs=self.epochNo,
          verbose=1,
          validation_data=(self.x_test, self.y_test))
        return self.model.evaluate(self.x_test, self.y_test, verbose=0) 
        
        
        


        
    


    

