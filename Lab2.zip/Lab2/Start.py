# -*- coding: utf-8 -*-
"""
Created on Thu Mar 12 12:58:50 2020

@author: Catalin
"""

from UI import Menu


def Start():
    Ui=Menu()
    Ui.MainMenu()
    
Start()